# PitMetric brand kit
Primary, compact PM, standalone mark and app-icon SVG variants.
Use dark variants on dark surfaces and light variants on light surfaces.
The Italian tricolour detail should remain subtle.
